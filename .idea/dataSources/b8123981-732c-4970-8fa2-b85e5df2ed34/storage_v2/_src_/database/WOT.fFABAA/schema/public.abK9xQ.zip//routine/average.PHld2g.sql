create function average() returns numeric
  language sql
as
$$
select avg(age) from cats;
$$;

alter function average() owner to postgres;

