create function "cals_Median"() returns trigger
  language plpgsql
as
$$
begin
update catsstat
set tail_length_median = (select percentile_cont(0.5) within group (order by tail_length) from cats)
where id = 1;
return NEW;
end;
$$;

alter function "cals_Median"() owner to postgres;

