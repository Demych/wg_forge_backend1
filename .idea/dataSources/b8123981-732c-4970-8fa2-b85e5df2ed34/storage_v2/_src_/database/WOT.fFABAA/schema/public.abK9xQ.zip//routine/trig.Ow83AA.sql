create function trig() returns integer
  language sql
as
$$
select age from cats
	where id = 1;
$$;

alter function trig() owner to postgres;

