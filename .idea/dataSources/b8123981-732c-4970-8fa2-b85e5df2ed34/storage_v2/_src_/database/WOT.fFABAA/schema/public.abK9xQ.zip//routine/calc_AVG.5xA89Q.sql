create function "calc_AVG"() returns trigger
  language plpgsql
as
$$
begin
update catsstat
set tail_length_mean = (select avg(tail_length) from cats)
where id = 1;
return NEW;
end;
$$;

alter function "calc_AVG"() owner to postgres;

