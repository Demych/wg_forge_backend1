create function "calc_AVG_median"() returns trigger
  language plpgsql
as
$$
begin
update cats_stat
set tail_length_mean = (select avg(tail_length) from cats), 
    whiskers_length_mean = (select avg(whiskers_length) from cats),
    tail_length_median = (select percentile_cont(0.5) within group (order by tail_length) from cats),
    whiskers_length_median = (select percentile_cont(0.5) within group (order by whiskers_length) from cats)
where id = 1;
return NEW;
end;
$$;

alter function "calc_AVG_median"() owner to postgres;

