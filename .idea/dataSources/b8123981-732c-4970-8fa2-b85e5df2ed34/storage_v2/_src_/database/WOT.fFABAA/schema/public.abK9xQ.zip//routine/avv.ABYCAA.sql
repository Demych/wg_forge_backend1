create function avv() returns void
  language sql
as
$$
update cats
set age = (select age from cats
	where id = 3)
where id = 2;
$$;

alter function avv() owner to postgres;

